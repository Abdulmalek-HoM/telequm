"""
Use-Case Lab — Scenario-Driven Experiments
============================================

Dashboard tab for running interactive experiments with:
- Multiple telecom problems (PRB, Routing, Beam, Energy, Handover)
- Multiple solvers (Greedy, SA, Exact, Hybrid, Quantum QAOA)
- Network topology and SINR visualizations
- Full simulation mode with time-series plots
"""

from __future__ import annotations

import json
import time

import numpy as np
import streamlit as st

from dashboard.utils.plot_helpers import (
    PALETTE,
    metrics_to_csv,
    plot_allocation_matrix,
    plot_fairness_sinr,
    plot_network_topology,
    plot_sinr_heatmap,
    plot_throughput_series,
)
from dashboard.utils.resource_monitor import (
    estimate_classical_resources,
    estimate_qaoa_resources,
    track_resources,
)
from dashboard.utils.scenario_loader import (
    build_config_from_sliders,
    list_presets,
    load_preset,
    parse_uploaded_yaml,
)
from dashboard.utils.snapshot_manager import run_problem_direct, run_scenario

try:
    import plotly.graph_objects as go
    HAS_PLOTLY = True
except ImportError:
    HAS_PLOTLY = False


PROBLEM_TYPES = {
    "📡 PRB Allocation": "prb_allocation",
    "🔀 Routing Optimization": "routing",
    "📶 Beam Selection": "beam_selection",
    "⚡ Energy Efficiency": "energy_efficiency",
    "🔄 Handover Optimization": "handover",
    "🏗️ BS Placement": "bs_placement",
    "🌐 Quantum Network Routing": "quantum_routing",
}

SOLVER_METHODS = {
    "🟢 Greedy (fast)": "greedy",
    "🔵 Simulated Annealing": "simulated_annealing",
    "🟡 Exact Brute-Force (small only)": "exact",
    "🟣 Hybrid — Quantum First": "hybrid_quantum_first",
    "🟠 Hybrid — Ensemble (best of all)": "hybrid_ensemble",
}


def render():
    """Render the Use-Case Lab tab."""
    st.header("🧪 Use-Case Lab")
    st.caption("Interactive experimentation across Quantum Optimization and Post-Quantum Cryptography")

    lab_mode = st.radio(
        "Select Experiment Domain",
        ["📡 Network Optimization Lab (QAOA/VQE)", "🛡️ Quantum-Safe Protocol & Crypto-Agility Lab"],
        horizontal=True,
        key="lab_domain_sel",
    )
    st.divider()

    if lab_mode == "📡 Network Optimization Lab (QAOA/VQE)":
        _render_optimization_lab()
    else:
        _render_pqc_protocol_lab()


def _render_pqc_protocol_lab():
    from dashboard.utils.plot_helpers import (
        plot_packet_fragmentation,
        plot_protocol_handshake_sequence,
    )
    from telequm.pqc.protocols import NETWORK_LINKS, ProtocolSimulator

    st.subheader("🛡️ Quantum-Safe Protocol & Crypto-Agility Lab")
    st.markdown("""
    Simulate real-world telecommunications cryptographic handshakes across different network links (5G RAN, Optical Backhaul, Satellite LEO, Core Mesh). Analyze packet expansion, MTU fragmentation, transmission latency, and CPU processing overhead when migrating from classical ECC/RSA to NIST FIPS 203/204 PQC algorithms!
    """)

    # ── 1. Protocol & Link Configuration ─────────────────────────
    st.subheader("1️⃣ Protocol & Link Configuration")
    c1, c2, c3 = st.columns(3)
    with c1:
        proto_sel = st.selectbox("Protocol", ["TLS_1_3", "IPSec_IKEv2", "MACsec", "5G_AKA", "DNSSEC_BGP"], key="lab_pqc_proto")
    with c2:
        link_sel = st.selectbox("Telecom Link Type", ["5G_UMa_RAN", "Optical_Backhaul", "Satellite_LEO", "Core_Mesh"], key="lab_pqc_link")
    with c3:
        suite_sel = st.selectbox("Cryptographic Suite", ["Classical", "PQC_Pure", "Hybrid"], key="lab_pqc_suite")

    # Link customizations
    with st.expander("⚙️ Customize Link Parameters (MTU, Latency, Loss)"):
        default_link = NETWORK_LINKS.get(link_sel, {})
        l1, l2, l3 = st.columns(3)
        with l1:
            mtu_val = st.number_input("Link MTU (Bytes)", min_value=500, max_value=9000, value=default_link.get("mtu_bytes", 1500), step=100, key="lab_pqc_mtu")
        with l2:
            lat_val = st.number_input("Base One-Way Latency (ms)", min_value=0.1, max_value=1000.0, value=default_link.get("latency_ms", 10.0), step=1.0, key="lab_pqc_lat")
        with l3:
            st.slider("Packet Loss (%)", min_value=0.0, max_value=10.0, value=default_link.get("packet_loss", 0.0) * 100, step=0.1, key="lab_pqc_loss")

    # ── 2. Run Simulation ────────────────────────────────────────
    st.subheader("2️⃣ Handshake Simulation Results")
    res = ProtocolSimulator.simulate_handshake(proto_sel, link_sel, suite_sel)

    if mtu_val != default_link.get("mtu_bytes", 1500) or lat_val != default_link.get("latency_ms", 10.0):
        st.caption(f"Note: Using custom MTU {mtu_val} B and latency {lat_val} ms.")
        res.mtu_exceeded = res.max_fragment_size > mtu_val
        res.fragmentation_count = int(np.ceil(res.max_fragment_size / mtu_val)) if res.mtu_exceeded else 1

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Total Latency", f"{res.total_latency_ms:.2f} ms")
    m2.metric("Total Handshake Bytes", f"{res.total_bytes:,} B")
    m3.metric("Max Fragment / MTU", f"{res.max_fragment_size:,} / {mtu_val} B", delta="MTU Exceeded!" if res.mtu_exceeded else "No Fragmentation", delta_color="inverse" if res.mtu_exceeded else "normal")
    m4.metric("Crypto CPU Processing", f"{res.cpu_processing_ms:.2f} ms")

    if HAS_PLOTLY:
        st.plotly_chart(plot_protocol_handshake_sequence(res.steps, f"{proto_sel} Handshake Step-by-Step Latency Breakdown"), use_container_width=True)

    # ── 3. Comparative Suite Benchmarking ────────────────────────
    st.subheader("3️⃣ Suite Benchmarking Comparison")
    st.markdown(f"Comparing all cryptographic suites for **{proto_sel}** over **{link_sel}**:")

    suites_dict = {
        "Classical": ProtocolSimulator.simulate_handshake(proto_sel, link_sel, "Classical").to_dict(),
        "PQC_Pure": ProtocolSimulator.simulate_handshake(proto_sel, link_sel, "PQC_Pure").to_dict(),
        "Hybrid": ProtocolSimulator.simulate_handshake(proto_sel, link_sel, "Hybrid").to_dict(),
    }

    if HAS_PLOTLY:
        st.plotly_chart(plot_packet_fragmentation(suites_dict, mtu_bytes=mtu_val), use_container_width=True)

    header = "| Cryptographic Suite | Total Bytes | Max Fragment | Fragmentation | Latency (ms) | CPU Time (ms) | Quantum Safe? |\n"
    header += "|---------------------|-------------|--------------|---------------|--------------|---------------|---------------|\n"
    rows = ""
    for s_name, s_data in suites_dict.items():
        q_safe = "❌ No" if s_name == "Classical" else ("✅ Yes (Dual)" if s_name == "Hybrid" else "✅ Yes (Pure)")
        frag_str = f"⚠️ {s_data['fragmentation_count']} pkts" if s_data["mtu_exceeded"] else "1 pkt"
        rows += f"| **{s_name}** | {s_data['total_handshake_bytes']:,} B | {s_data['max_fragment_size']:,} B | {frag_str} | {s_data['total_latency_ms']:.2f} ms | {s_data['cpu_processing_ms']:.2f} ms | {q_safe} |\n"
    st.markdown(header + rows)

    csv_data = "Suite,TotalBytes,MaxFragment,FragmentationCount,LatencyMS,CPUProcessingMS\n"
    for s_name, s_data in suites_dict.items():
        csv_data += f"{s_name},{s_data['total_handshake_bytes']},{s_data['max_fragment_size']},{s_data['fragmentation_count']},{s_data['total_latency_ms']:.2f},{s_data['cpu_processing_ms']:.2f}\n"

    st.download_button(
        label="📥 Download Protocol Benchmark CSV Report",
        data=csv_data,
        file_name=f"{proto_sel}_{link_sel}_pqc_benchmark.csv",
        mime="text/csv",
    )

    with st.expander("📚 Handshake Simulation & Link Benchmarking Methodology", expanded=False):
        st.markdown("""
        ### ⚙️ How Are Handshake Bytes, Latency & CPU Overhead Simulated?
        The protocol simulator models the physical and cryptographic realities of telecommunications links without guesswork:

        1. **Handshake Payload & MTU Fragmentation:**
           - **Payload Sizing:** Sums X.509 certificate chains (dual-signed or pure PQC Dilithium3 certs $\\sim 3.3\\text{ KB}$ each), KEM encapsulation public keys/ciphertexts ($1,184\\text{ B}$ and $1,088\\text{ B}$ for ML-KEM-768), and protocol framing overhead per **IETF RFC 8446 (TLS 1.3)** and **RFC 9370 (Multiple Key Exchanges in IKEv2)**.
           - **Fragmentation Calculation:** Splits total handshake bytes across link MTU (Ethernet $1500\\text{ B}$, IPv6 minimum $1280\\text{ B}$, Jumbo Frames $9000\\text{ B}$). Whenever packet size exceeds MTU, IP fragmentation occurs, multiplying packet loss vulnerability and retransmission jitter in RAN/optical channels.

        2. **Transmission Latency & CPU Processing Time:**
           - **Physical Propagation Delay:** Modeled using speed of light in optical fiber ($\\sim 5\\text{ }\\mu\\text{s/km}$ per **ITU-T G.8271**), satellite LEO orbital round-trip delays ($60\\text{--}80\\text{ ms}$ per **3GPP TR 38.811**), and 5G RAN URLLC air-interface budgets ($<1\\text{ ms}$ per **3GPP TS 38.300**).
           - **CPU Processing Time:** Derived by dividing empirical cryptographic cycle counts (from OpenSSL 3.2 OQS provider benchmarks) by an assumed $2.5\\text{ GHz}$ telecom control-plane processor clock speed:
             $$T_{\\text{cpu}} = \\frac{\\text{Cycles}_{\\text{encap}} + \\text{Cycles}_{\\text{decap}} + \\text{Cycles}_{\\text{verify}}}{\\text{Processor Clock Frequency}}$$

        3. **Standardization References:**
           - *IETF RFC 9370:* Multiple Key Exchanges in IKEv2 (Internet Engineering Task Force).
           - *3GPP TS 33.501:* Security architecture and procedures for 5G System (3GPP).
           - *ETSI GR QSC 004 / 006:* Quantum-Safe Cryptography; Protocol integration and hybrid key exchanges.
        """)


def _render_optimization_lab():
    """Render the classical/quantum optimization lab."""
    # ── 1. Network Setup ─────────────────────────────────────────
    st.subheader("1️⃣ Network Configuration")
    config = _network_config()

    # ── 2. Problem Selection ─────────────────────────────────────
    st.subheader("2️⃣ Problem Formulation")
    col_p1, col_p2 = st.columns(2)
    with col_p1:
        problem_label = st.selectbox("Telecom Problem", list(PROBLEM_TYPES.keys()), key="lab_problem")
    problem_type = PROBLEM_TYPES[problem_label]
    with col_p2:
        n_bs = len(config.get("network", {}).get("base_stations", []))
        n_ue = len(config.get("network", {}).get("users", []))
        var_est = _estimate_vars(problem_type, n_ue, n_bs)
        st.metric("QUBO Variables", f"{var_est}", help="Number of binary variables in the QUBO")

    _problem_description(problem_type)

    # ── 3. Solver Selection ──────────────────────────────────────
    st.subheader("3️⃣ Solver Selection")
    col_s1, col_s2 = st.columns(2)
    with col_s1:
        solver_label = st.selectbox("Classical / Hybrid Solver", list(SOLVER_METHODS.keys()), key="lab_solver")
    solver_method = SOLVER_METHODS[solver_label]

    with col_s2:
        run_quantum = st.toggle("⚛️ Compare with Quantum (QAOA)", value=False, key="lab_quantum")
        if run_quantum:
            max_q = st.slider("Max quantum variables", 4, 100, 20, key="lab_max_q")
            config.setdefault("solver", {})["max_quantum_vars"] = max_q
            if max_q > 50:
                st.warning(
                    "🔴 **>50 qubits** — Statevector simulation requires **multi-CPU or GPU** "
                    f"architecture. RAM: ~{2**max_q * 16 / (1024**3):.0f} GB. Expect long runtimes on standard hardware."
                )
            elif max_q > 30:
                st.info(
                    "🟡 **>30 qubits** — Simulation will be slow on a single CPU. "
                    f"RAM estimate: ~{2**max_q * 16 / (1024**3):.2f} GB statevector."
                )
            if var_est > max_q:
                st.warning(f"⚠️ Problem has **{var_est}** vars but quantum limit is **{max_q}**. "
                           f"Reduce network size or increase limit.")

    # ── 4. Simulation Mode ───────────────────────────────────────
    st.subheader("4️⃣ Experiment Mode")
    mode = st.radio(
        "Mode",
        ["⚡ Single-Shot QUBO", "📈 Full Simulation (with time-series)"],
        horizontal=True, key="lab_mode",
    )

    if mode == "📈 Full Simulation (with time-series)":
        c1, c2, c3 = st.columns(3)
        with c1:
            timesteps = st.slider("Timesteps", 10, 100, 30, key="lab_ts")
        with c2:
            traffic = st.selectbox("Traffic Model", ["poisson", "video", "iot"], key="lab_traffic")
        with c3:
            mobility = st.selectbox("Mobility Model", ["pedestrian", "random_waypoint", "vehicular"],
                                    key="lab_mobility")
        config["simulation"] = {
            "num_timesteps": timesteps, "dt": 1.0,
            "random_seed": config.get("network", {}).get("random_seed", 42),
            "channel_update_interval": 5, "optimization_interval": 5,
        }
        config["traffic"] = {"model": traffic, "arrival_rate": 1.0, "session_rate_mbps": 5.0}
        config["mobility"] = {"model": mobility, "speed_mean": 1.2}
        config["solver"] = {"classical_method": solver_method.split("hybrid_")[0] if "hybrid" in solver_method else solver_method,
                            "run_quantum": False}

    # ── 5. Run ───────────────────────────────────────────────────
    st.divider()
    if st.button("🚀 Run Experiment", type="primary", use_container_width=True):
        if mode == "⚡ Single-Shot QUBO":
            _run_single_shot(config, problem_type, solver_method, run_quantum)
        else:
            _run_full_simulation(config, problem_type, solver_method)

    with st.expander("📚 Optimization & Quantum Simulation Methodology", expanded=False):
        st.markdown("""
        ### 🧮 How Are QUBO Variables & Statevector RAM Calculated?
        1. **QUBO Variable Estimation:**
           - For **PRB Allocation / Routing / Beamforming**, binary decision variables scale as $|V| = N_{\\text{users}} \\times N_{\\text{base\\_stations}} \\times N_{\\text{subcarriers}}$.
           - Telecommunications optimization problems are mapped to Quadratic Unconstrained Binary Optimization (QUBO) matrices $\\mathbf{Q}$, where diagonal entries represent linear node costs and off-diagonal entries penalize constraint violations (e.g., interference or capacity overflow).

        2. **Statevector RAM Formula:**
           - Exact statevector simulation of $n$ qubits requires tracking $2^n$ complex amplitudes:
             $$\\text{RAM Bytes} = 2^n \\times 16\\text{ bytes (complex128)}$$
           - For $n=30$ qubits, this requires $2^{30} \\times 16 = 17.18\\text{ GB}$ of RAM; for $n=40$ qubits, it requires $17.59\\text{ TB}$. This mathematical reality illustrates why hybrid quantum-classical algorithms (QAOA/VQE) must be tested on classical supercomputers or QPUs!

        3. **References:**
           - *Farhi, E. et al. (2014):* "A Quantum Approximate Optimization Algorithm" (arXiv:1411.4028).
           - *Peruzzo, A. et al. (2014):* "A variational eigenvalue solver on a photonic quantum processor", Nature Communications.
        """)


# ─── Network Config Builder ──────────────────────────────────────

def _network_config() -> dict:
    source = st.radio("Source", ["🎛️ Sliders", "📁 Preset", "📤 Upload YAML"],
                      horizontal=True, key="lab_source")

    if source == "📁 Preset":
        presets = list_presets()
        if presets:
            idx = st.selectbox("Preset", range(len(presets)),
                               format_func=lambda i: presets[i]["name"], key="lab_preset")
            return load_preset(presets[idx]["path"])
        st.warning("No presets found")

    if source == "📤 Upload YAML":
        up = st.file_uploader("YAML config", type=["yaml", "yml"], key="lab_upload")
        if up:
            try:
                return parse_uploaded_yaml(up.read().decode())
            except ValueError as e:
                st.error(str(e))

    # Default: sliders
    c1, c2, c3 = st.columns(3)
    with c1:
        num_bs = st.slider("Base Stations", 2, 8, 3, key="lab_bs")
        tx_power = st.slider("Tx Power (dBm)", 30.0, 50.0, 46.0, key="lab_txp")
    with c2:
        num_ue = st.slider("Users", 2, 20, 6, key="lab_ue")
        freq = st.slider("Frequency (GHz)", 0.7, 6.0, 3.5, 0.1, key="lab_freq")
    with c3:
        area = st.slider("Area (m)", 200, 3000, 1000, 100, key="lab_area")
        seed = st.number_input("Seed", 0, 9999, 42, key="lab_seed")

    return build_config_from_sliders(
        num_bs=num_bs, num_ue=num_ue,
        area_width=float(area), area_height=float(area),
        tx_power_dbm=tx_power, frequency_ghz=freq,
        num_timesteps=1, seed=int(seed),
    )


# ─── Problem Info ─────────────────────────────────────────────────

def _problem_description(problem_type: str):
    descriptions = {
        "prb_allocation": (
            "**PRB Allocation** — Assign users to base stations maximising SINR-weighted throughput. "
            "Constraints: each user → one BS, per-BS capacity."
        ),
        "routing": (
            "**Routing** — Find optimal routing paths through cell graph, "
            "weighted by aggregate SINR strength."
        ),
        "beam_selection": (
            "**Beam Selection** — Select discrete beams from a codebook for each user. "
            "One beam per user constraint."
        ),
        "energy_efficiency": (
            "**Energy Efficiency** — Decide which cells to keep active (cell on/off) "
            "while maintaining coverage. Trade-off: SINR vs energy."
        ),
        "handover": (
            "**Handover Optimization** — Reassign users to cells while minimising "
            "unnecessary handovers. Penalises deviations from current serving cell."
        ),
        "bs_placement": (
            "**BS Placement** — Facility location: select which candidate sites to build "
            "base stations on, maximising coverage under a budget constraint."
        ),
        "quantum_routing": (
            "**Quantum Network Routing** — Route entanglement / QKD keys through a "
            "network of quantum repeaters, maximising end-to-end fidelity."
        ),
    }
    st.info(descriptions.get(problem_type, ""))


def _estimate_vars(problem_type: str, n_ue: int, n_bs: int) -> int:
    if problem_type == "prb_allocation":
        return n_ue * n_bs
    elif problem_type == "routing":
        return n_bs * n_bs
    elif problem_type == "beam_selection":
        return n_ue * 8
    elif problem_type == "energy_efficiency":
        return n_bs + n_ue * n_bs
    elif problem_type == "handover":
        return n_ue * n_bs
    elif problem_type == "bs_placement":
        return n_bs
    elif problem_type == "quantum_routing":
        return n_bs * n_bs
    return n_ue * n_bs


# ─── Single-Shot QUBO Execution ──────────────────────────────────

def _run_single_shot(config: dict, problem_type: str, solver_method: str, run_quantum: bool):
    with st.spinner(f"Solving {problem_type} with {solver_method}..."):
        with track_resources() as res_report:
            results = run_problem_direct(
                config, problem_type=problem_type,
                solver_method=solver_method, run_quantum=run_quantum,
            )
        total = res_report.wall_time_s

    st.success(f"✅ Complete in **{total:.2f}s** — {results['num_vars']} QUBO variables")

    # ── KPI Cards ────────────────────────────────────────────────
    info = results["snapshot_info"]
    c_met = results.get("classical_metrics") or {}

    k1, k2, k3, k4 = st.columns(4)
    k1.metric("🏗️ Cells", info["num_cells"])
    k2.metric("👥 Users", info["num_users"])
    k3.metric("📊 QUBO Vars", results["num_vars"])
    k4.metric("⏱️ Runtime", f"{total:.3f}s")

    # ── 📍 Network State ─────────────────────────────────────────
    st.subheader("📍 Network State")
    bs_pos = results.get("bs_positions")
    ue_pos = results.get("ue_positions")
    sinr_mat = results.get("sinr_matrix")
    serving = results.get("serving_cells")

    if bs_pos is not None and ue_pos is not None:
        col_topo, col_sinr = st.columns(2)

        with col_topo:
            fig = plot_network_topology(
                bs_pos, ue_pos, serving,
                tuple(info["area_size"]),
                title="Network Topology + Association",
            )
            st.plotly_chart(fig, use_container_width=True)

        with col_sinr:
            if sinr_mat is not None:
                fig = plot_sinr_heatmap(
                    sinr_mat, title="SINR Matrix (UE × Cell)"
                )
                st.plotly_chart(fig, use_container_width=True)

    # ── Allocation Matrix ────────────────────────────────────────
    alloc = results.get("allocation_matrix")
    if alloc is not None and isinstance(alloc, np.ndarray) and alloc.ndim == 2:
        st.subheader("🗺️ Allocation Heatmap")
        fig = plot_allocation_matrix(alloc)
        st.plotly_chart(fig, use_container_width=True)

    # ── Classical Result ─────────────────────────────────────────
    st.subheader("📊 Classical Result")
    c_res = results["classical_result"]

    col1, col2, col3 = st.columns(3)
    col1.metric("Method", c_res.get("method", solver_method).replace("_", " ").title())
    col2.metric("QUBO Cost", f"{c_res.get('cost', 'N/A')}")
    col3.metric("Runtime", f"{c_res.get('runtime_s', 0) * 1000:.1f} ms")

    if c_met:
        mc1, mc2, mc3 = st.columns(3)
        mc1.metric("Avg Throughput", f"{c_met.get('avg_throughput_mbps', 0):.1f} Mbps")
        mc2.metric("Sum Throughput", f"{c_met.get('sum_throughput_mbps', 0):.1f} Mbps")
        mc3.metric("Jain Fairness", f"{c_met.get('fairness_jain', 0):.3f}")

    # ── Quantum Result ───────────────────────────────────────────
    st.subheader("⚛️ Quantum Result")
    q_res = results.get("quantum_result")
    q_met = results.get("quantum_metrics") or {}

    if q_res is None:
        st.info("Quantum comparison not enabled. Toggle the ⚛️ switch above to compare.")
    elif "error" in q_res:
        st.warning(f"**Quantum could not run:** {q_res['error']}")
        if "num_vars" in q_res:
            st.caption(f"💡 Tip: Reduce to ≤ {q_res.get('max_quantum_vars', 20)} vars "
                       f"(current: {q_res['num_vars']} vars)")
    else:
        col1, col2, col3 = st.columns(3)
        col1.metric("Method", q_res.get("method", "QAOA").replace("_", " ").title())
        col2.metric("QUBO Cost", f"{q_res.get('cost', 'N/A')}")
        col3.metric("Runtime", f"{q_res.get('runtime_s', 0) * 1000:.1f} ms")

        if c_res.get("cost") and q_res.get("cost"):
            c_cost, q_cost = float(c_res["cost"]), float(q_res["cost"])
            if c_cost != 0:
                improvement = (c_cost - q_cost) / abs(c_cost) * 100
                st.metric("⚡ Quantum vs Classical",
                          f"{improvement:+.1f}%",
                          delta="Better" if improvement > 0 else "Worse")

        if q_met:
            mc1, mc2 = st.columns(2)
            mc1.metric("Q Throughput", f"{q_met.get('avg_throughput_mbps', 0):.1f} Mbps")
            mc2.metric("Q Fairness", f"{q_met.get('fairness_jain', 0):.3f}")

        # ── 🔬 Quantum Circuit Execution Details ─────────────────
        st.subheader("🔬 Quantum Circuit Execution")

        # Circuit stats
        cs1, cs2, cs3, cs4 = st.columns(4)
        cs1.metric("🔲 Qubits", q_res.get("num_qubits", q_res.get("num_vars", "?")))
        cs2.metric("📏 Depth", q_res.get("circuit_depth", "?"))
        cs3.metric("🧩 Gates", q_res.get("gate_count", "?"))
        cs4.metric("🎯 Shots", q_res.get("shots", 1024))

        # Circuit diagram
        circuit_text = q_res.get("circuit_text", "")
        if circuit_text:
            with st.expander("📐 Circuit Diagram", expanded=True):
                st.code(circuit_text, language=None)

        # Optimal parameters
        opt_params = q_res.get("optimal_params")
        if opt_params:
            with st.expander("🎛️ Optimal QAOA/VQE Parameters"):
                p = len(opt_params) // 2
                gamma = opt_params[:p]
                beta = opt_params[p:]
                param_rows = ""
                for i in range(p):
                    param_rows += f"| Layer {i+1} | {gamma[i]:.6f} | {beta[i]:.6f} |\n"
                st.markdown(f"""
| Layer | γ (cost) | β (mixer) |
|-------|----------|-----------|
{param_rows}
                """)

        # Convergence info
        conv = q_res.get("convergence_info", {})
        if conv:
            with st.expander("📊 Convergence Info"):
                ci1, ci2, ci3 = st.columns(3)
                ci1.metric("Func Evals", conv.get("nfev", "?"))
                ci2.metric("Converged", "✅" if conv.get("success") else "❌")
                ci3.metric("Final Cost", f"{conv.get('final_cost', 0):.4f}")
                if conv.get("message"):
                    st.caption(f"Optimizer: {conv['message']}")

        # Optimization history (convergence plot)
        history = q_res.get("optimization_history", [])
        if history and HAS_PLOTLY:
            with st.expander("📈 Convergence Plot", expanded=True):
                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=list(range(len(history))), y=history,
                    mode="lines+markers",
                    line={"color": PALETTE["primary"], "width": 2},
                    marker={"size": 4},
                    name="Cost per Iteration",
                ))
                fig.update_layout(
                    title="QAOA/VQE Optimization Convergence",
                    xaxis_title="Iteration", yaxis_title="Expectation Value",
                    plot_bgcolor=PALETTE["bg"], paper_bgcolor=PALETTE["card"],
                    font={"color": PALETTE["text"]}, height=350,
                )
                fig.update_xaxes(gridcolor=PALETTE["grid"])
                fig.update_yaxes(gridcolor=PALETTE["grid"])
                st.plotly_chart(fig, use_container_width=True)

        # Measurement distribution
        counts = q_res.get("measurement_counts", {})
        if counts and HAS_PLOTLY:
            with st.expander("🎲 Measurement Distribution (Top 15)"):
                sorted_counts = sorted(counts.items(), key=lambda x: -x[1])[:15]
                labels = [c[0] for c in sorted_counts]
                values = [c[1] for c in sorted_counts]
                fig = go.Figure(data=[go.Bar(
                    x=labels, y=values,
                    marker_color=PALETTE["primary"],
                )])
                fig.update_layout(
                    title="Measurement Counts (Top Bitstrings)",
                    xaxis_title="Bitstring", yaxis_title="Count",
                    plot_bgcolor=PALETTE["bg"], paper_bgcolor=PALETTE["card"],
                    font={"color": PALETTE["text"]}, height=350,
                    xaxis={"tickangle": 45},
                )
                st.plotly_chart(fig, use_container_width=True)

    # ── 📋 Problem-Specific Evaluation ────────────────────────────
    st.subheader("📋 Solution Evaluation")
    _show_evaluation_metrics(problem_type, c_res, c_met, q_res, q_met)

    # ── 🖥️ Resource Usage ─────────────────────────────────────────
    st.subheader("🖥️ Compute Resources Used")
    rc1, rc2, rc3, rc4 = st.columns(4)
    rc1.metric("⏱️ Wall Time", f"{res_report.wall_time_s * 1000:.1f} ms")
    rc2.metric("🧠 Peak RAM", f"{res_report.peak_ram_mb:.2f} MB")
    rc3.metric("🔧 CPU Time", f"{res_report.cpu_time_s * 1000:.1f} ms")
    rc4.metric("📊 QUBO Vars", results["num_vars"])

    # Show estimated resources for the algorithm
    n_vars = results["num_vars"]
    if "hybrid" in solver_method or solver_method == "greedy":
        est = estimate_classical_resources(n_vars, "greedy")
    elif solver_method == "simulated_annealing":
        est = estimate_classical_resources(n_vars, "simulated_annealing")
    elif solver_method == "exact":
        est = estimate_classical_resources(n_vars, "exact")
    else:
        est = estimate_classical_resources(n_vars, "greedy")

    with st.expander("📐 Algorithm Complexity Estimate"):
        st.markdown(f"""
        | Property | Value |
        |----------|-------|
        | **Algorithm** | {est.get('algorithm', solver_method)} |
        | **Time Complexity** | {est.get('time_complexity', 'N/A')} |
        | **Space Complexity** | {est.get('space_complexity', 'N/A')} |
        | **Estimated RAM** | {est.get('ram_mb', 0):.4f} MB |
        | **Actual Peak RAM** | {res_report.peak_ram_mb:.2f} MB |
        """)
        if run_quantum:
            q_est = estimate_qaoa_resources(n_vars, 2, n_vars * (n_vars - 1) // 2)
            st.markdown(f"""
        | **QAOA Qubits** | {q_est['num_qubits']} |
        | **QAOA Gates** | {q_est['total_gates']} |
        | **QAOA Depth** | {q_est['circuit_depth']} |
        | **Statevector RAM** | {q_est['ram_mb']:,.2f} MB |
            """)

    # ── Export ────────────────────────────────────────────────────
    st.divider()
    _export_section(results, c_res, q_res, c_met, q_met)


# ─── Full Simulation Mode ────────────────────────────────────────

def _run_full_simulation(config: dict, problem_type: str, solver_method: str):
    with st.spinner("Running full simulation..."):
        t0 = time.time()
        results = run_scenario(config, verbose=False)
        total = time.time() - t0

    metrics = results.get("metrics", [])
    classical = results.get("classical_solutions", [])
    env_final = results.get("environment_final", {})

    st.success(f"✅ Simulation complete in **{total:.2f}s** — {len(metrics)} timesteps")

    if not metrics:
        st.warning("No metrics collected.")
        return

    # ── KPI Banner ───────────────────────────────────────────────
    last, first = metrics[-1], metrics[0]
    k1, k2, k3, k4 = st.columns(4)
    k1.metric("📶 Throughput", f"{last['avg_throughput_mbps']:.1f}",
              delta=f"{last['avg_throughput_mbps'] - first['avg_throughput_mbps']:+.1f}")
    k2.metric("📡 SINR", f"{last['avg_sinr_db']:.1f} dB")
    k3.metric("⚖️ Fairness", f"{last['fairness_jain']:.3f}",
              delta=f"{last['fairness_jain'] - first['fairness_jain']:+.3f}")
    k4.metric("👥 Active UEs", last["num_active_ues"])

    # ── 📍 Network State ─────────────────────────────────────────
    st.subheader("📍 Network State")
    bs_pos = np.array([bs["position"] for bs in env_final.get("base_stations", [])])
    ue_pos = np.array([ue["position"] for ue in env_final.get("users", [])])
    serving = np.array([ue.get("serving_bs", -1) for ue in env_final.get("users", [])])
    area_size = tuple(env_final.get("area_size", [1000, 1000]))

    if len(bs_pos) > 0 and len(ue_pos) > 0:
        bs_ids = [bs["id"] for bs in env_final.get("base_stations", [])]
        serving_idx = np.array([bs_ids.index(s) if s in bs_ids else -1 for s in serving])
        st.plotly_chart(
            plot_network_topology(bs_pos, ue_pos, serving_idx, area_size,
                                  title="Final Network Topology"),
            use_container_width=True,
        )

    # ── 📈 Performance Over Time ─────────────────────────────────
    st.subheader("📈 Performance Over Time")
    t1, t2 = st.columns(2)
    with t1:
        st.plotly_chart(plot_throughput_series(metrics), use_container_width=True)
    with t2:
        st.plotly_chart(plot_fairness_sinr(metrics), use_container_width=True)

    # ── 🔧 Solver Costs Over Time ────────────────────────────────
    if classical and HAS_PLOTLY:
        st.subheader("🔧 Solver Costs Over Time")
        costs = [s["cost"] for s in classical]
        times = [s["timestep"] for s in classical]
        fig = go.Figure()
        fig.add_trace(go.Scatter(
            x=times, y=costs, mode="lines+markers",
            line={"color": PALETTE["primary"], "width": 2},
            marker={"size": 6}, name="Classical Cost",
        ))
        fig.update_layout(
            title="QUBO Cost at Optimization Steps",
            xaxis_title="Timestep", yaxis_title="Cost",
            plot_bgcolor=PALETTE["bg"], paper_bgcolor=PALETTE["card"],
            font={"color": PALETTE["text"]}, height=350,
        )
        fig.update_xaxes(gridcolor=PALETTE["grid"])
        fig.update_yaxes(gridcolor=PALETTE["grid"])
        st.plotly_chart(fig, use_container_width=True)

    # ── Export ────────────────────────────────────────────────────
    st.divider()
    csv_data = metrics_to_csv(metrics)
    st.download_button("⬇️ Download Metrics CSV", csv_data,
                       "telequm_metrics.csv", "text/csv")


# ─── Export Section ───────────────────────────────────────────────

def _export_section(results, c_res, q_res, c_met, q_met):
    st.subheader("📥 Export")
    export = {
        "problem_type": results["problem_type"],
        "solver_method": results["solver_method"],
        "num_vars": results["num_vars"],
        "classical_cost": c_res.get("cost"),
        "quantum_cost": q_res.get("cost") if q_res and "cost" in q_res else None,
        "classical_metrics": c_met,
        "quantum_metrics": q_met,
    }
    st.download_button("⬇️ Download Results JSON",
                       json.dumps(export, indent=2, default=str),
                       "telequm_results.json", "application/json")


# ─── Problem-Specific Evaluation ─────────────────────────────────

def _show_evaluation_metrics(problem_type, c_res, c_met, q_res, q_met):
    """Display problem-specific evaluation metrics side-by-side."""

    def _fmt(v, fmt=".2f"):
        if v is None or v == 0:
            return "—"
        return f"{v:{fmt}}"

    if problem_type == "prb_allocation":
        st.markdown("**PRB Allocation Evaluation**")
        cols = st.columns(4)
        cols[0].metric("C: Throughput", f"{c_met.get('avg_throughput_mbps', 0):.1f} Mbps")
        cols[1].metric("C: Fairness", _fmt(c_met.get('fairness_jain')))
        if q_met:
            cols[2].metric("Q: Throughput", f"{q_met.get('avg_throughput_mbps', 0):.1f} Mbps")
            cols[3].metric("Q: Fairness", _fmt(q_met.get('fairness_jain')))

    elif problem_type == "routing":
        st.markdown("**Routing Evaluation**")
        cols = st.columns(3)
        cols[0].metric("C: Edges Used", c_met.get("num_edges", "—"))
        cols[1].metric("C: Cost", _fmt(c_res.get("cost")))
        if q_res and "cost" in q_res:
            cols[2].metric("Q: Cost", _fmt(q_res.get("cost")))

    elif problem_type == "beam_selection":
        st.markdown("**Beam Selection Evaluation**")
        cols = st.columns(3)
        cols[0].metric("C: Assigned", c_met.get("num_assigned", "—"))
        cols[1].metric("C: Cost", _fmt(c_res.get("cost")))
        if q_res and "cost" in q_res:
            cols[2].metric("Q: Cost", _fmt(q_res.get("cost")))

    elif problem_type == "energy_efficiency":
        st.markdown("**Energy Efficiency Evaluation**")
        cols = st.columns(4)
        cols[0].metric("C: Active Cells", c_met.get("active_cells", "—"))
        cols[1].metric("C: Energy Saved", f"{c_met.get('energy_saved_pct', 0):.1f}%")
        if q_met:
            cols[2].metric("Q: Active Cells", q_met.get("active_cells", "—"))
            cols[3].metric("Q: Energy Saved", f"{q_met.get('energy_saved_pct', 0):.1f}%")

    elif problem_type == "handover":
        st.markdown("**Handover Evaluation**")
        cols = st.columns(3)
        cols[0].metric("C: Handovers", c_met.get("num_handovers", "—"))
        cols[1].metric("C: Cost", _fmt(c_res.get("cost")))
        if q_res and "cost" in q_res:
            cols[2].metric("Q: Handovers", q_met.get("num_handovers", "—") if q_met else "—")

    elif problem_type == "bs_placement":
        st.markdown("**BS Placement Evaluation**")
        cols = st.columns(4)
        cols[0].metric("C: Sites Selected", c_met.get("sites_selected", "—"))
        cols[1].metric("C: Budget Used", f"{c_met.get('utilisation_pct', 0):.0f}%")
        cols[2].metric("C: Cost", _fmt(c_res.get("cost")))
        if q_met:
            cols[3].metric("Q: Sites Selected", q_met.get("sites_selected", "—"))

    elif problem_type == "quantum_routing":
        st.markdown("**Quantum Network Routing Evaluation**")
        cols = st.columns(4)
        cols[0].metric("C: Hops", c_met.get("num_hops", "—"))
        cols[1].metric("C: Fidelity", _fmt(c_met.get("end_to_end_fidelity"), ".4f"))
        if q_met:
            cols[2].metric("Q: Hops", q_met.get("num_hops", "—"))
            cols[3].metric("Q: Fidelity", _fmt(q_met.get("end_to_end_fidelity"), ".4f"))

    else:
        st.caption("No specific evaluation metrics for this problem type.")

