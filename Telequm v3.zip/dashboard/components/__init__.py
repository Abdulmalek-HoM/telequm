"""Dashboard components package."""
